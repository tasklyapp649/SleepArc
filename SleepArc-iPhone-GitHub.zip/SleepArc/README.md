# SleepArc — version iPhone (Expo)

Cette version transforme l'artefact Claude `SleepArc.tsx` en application React Native/Expo.

## 1. Installer Node.js
Installe Node.js LTS sur ton ordinateur.

## 2. Installer les dépendances
Dans ce dossier :

```bash
npm install
```

## 3. Tester sur l'iPhone
Installe Expo Go sur l'iPhone, puis :

```bash
npx expo start
```

Scanne le QR code avec l'iPhone.

## 4. Créer une vraie app installable
Pour une build iOS distribuable, utilise EAS Build :

```bash
npx eas login
npx eas build:configure
npx eas build --platform ios
```

Une build iOS nécessite un compte Apple Developer pour une distribution normale sur appareil.

## Note Apple Santé
La version actuelle conserve le fonctionnement de ton artefact : elle reçoit les données Santé via le JSON copié par un Raccourci Apple. Elle ne lit pas encore directement HealthKit.
